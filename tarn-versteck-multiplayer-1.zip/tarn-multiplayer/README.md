# Tarn-Versteck – Multiplayer (inspiriert von Meccha Chameleon)

Eigenständiges Hide-and-Seek-Tarnspiel: Verstecken-Team bemalt sich passend zur
Umgebung, Sucher-Team jagt mit Sichtkegel und begrenzten Schüssen. Bis zu 10
Spieler pro Runde, echter Server, funktioniert im Handy-Browser.

## Lokal testen

Voraussetzung: Node.js 18+ ist installiert.

```
npm install
npm start
```

Danach im Browser öffnen: `http://localhost:3000`

Für Tests mit mehreren Handys im selben WLAN: statt `localhost` die lokale
IP deines Rechners verwenden, z. B. `http://192.168.1.23:3000` (IP mit
`ipconfig` / `ifconfig` herausfinden). Alle Geräte müssen im selben Netzwerk sein.

## Online hosten (damit Freunde von überall beitreten können)

Der Server braucht dauerhaftes Hosting, da er WebSocket-Verbindungen offen hält.
Funktioniert z. B. auf jedem Node.js-fähigen Host. Grober Ablauf, egal welcher
Anbieter:

1. Diesen Ordner in ein Git-Repository packen (GitHub reicht).
2. Beim Hosting-Anbieter ein neues Web Service / App-Projekt aus dem Repo anlegen.
3. Start-Befehl: `npm start` (steht schon in `package.json`).
4. Der Anbieter setzt automatisch die Umgebungsvariable `PORT` – der Server
   liest sie bereits selbstständig aus (`process.env.PORT`).
5. Nach dem Deploy bekommst du eine öffentliche URL (z. B. `https://dein-app-name.onrender.com`)
   – die einfach mit den Mitspielern teilen, im Handy-Browser öffnen, fertig.

Anbieter mit kostenlosen/günstigen Einstiegsstufen für genau so einen kleinen
Node.js-Server: Render, Railway, Fly.io, Glitch. Die Schritte sind bei allen
sehr ähnlich (Repo verbinden → Start-Befehl bestätigen → deployen). Wenn du dich
für einen entscheidest, kann ich dir die genauen Klicks dafür geben.

## Spielablauf

- Ein Spieler erstellt einen Raum (4-stelliger Code), andere treten mit dem
  Code bei.
- Host startet die Runde ab 2 Spielern. Rollen (Sucher/Versteck) werden
  automatisch verteilt (~1 Sucher pro 4 Spieler).
- **Versteck-Phase (12s):** Verstecken-Team bewegt sich und drückt „TARNEN“,
  um die Farbe der aktuellen Fläche anzunehmen. Sucher warten.
- **Such-Phase (90s):** Sucher bewegen sich, ihr Sichtkegel ist sichtbar.
  „SCHUSS“ trifft den nächsten Versteck-Spieler im Kegel (Abklingzeit ~1,4s).
  Verstecken-Team kann weiter fliehen und sich neu tarnen.
- Punkte: Verstecken-Team sammelt automatisch Punkte fürs Überleben plus Bonus
  fürs riskante „im Sichtkegel stehen ohne getroffen zu werden“. Sucher
  bekommen Punkte pro Treffer.
- Runde endet nach Zeitablauf oder wenn alle im Versteck-Team getroffen wurden.

## Bekannte Grenzen dieser Version

- Kein Login/Accounts, keine Datenbank – alles lebt nur im Arbeitsspeicher des
  Servers, solange er läuft.
- Kein Anti-Cheat; für einen privaten Freundeskreis aber unproblematisch.
- Namen/Look/Branding sind bewusst eigenständig gehalten und nicht identisch
  mit dem Original auf Steam.

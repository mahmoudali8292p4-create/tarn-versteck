const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const path = require('path');

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: '*' } });

app.use(express.static(path.join(__dirname, 'public')));

// ---- fixed world/simulation space (independent of any device's screen size) ----
const WORLD_W = 900;
const WORLD_H = 1400;
const TILE_COLS = 6;
const TILE_ROWS = 9;
const PLAYER_R = 18;
const PLAYER_SPEED = 4.2; // world units per tick
const TICK_MS = 50; // 20Hz
const HIDE_PHASE_SEC = 12;
const SEEK_PHASE_SEC = 90;
const MAX_PLAYERS = 10;
const SEEKER_RATIO = 0.25; // ~1 seeker per 4 players
const SHOOT_RANGE = 260;
const SHOOT_FOV = Math.PI / 3; // 60 degrees
const SHOOT_COOLDOWN_MS = 1400;
const SPOT_BONUS_COOLDOWN_MS = 4000;

const PALETTE = ['#8b5cf6', '#4cc26b', '#f4b740', '#e6483c', '#2de1c2', '#3a4a52', '#c96f9e', '#5b7db1'];

function makeRoomCode() {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let code = '';
  for (let i = 0; i < 4; i++) code += chars[Math.floor(Math.random() * chars.length)];
  return code;
}

function buildMap() {
  const tw = WORLD_W / TILE_COLS, th = WORLD_H / TILE_ROWS;
  const tiles = [];
  for (let r = 0; r < TILE_ROWS; r++) {
    for (let c = 0; c < TILE_COLS; c++) {
      tiles.push({
        x: c * tw, y: r * th, w: tw, h: th,
        color: PALETTE[(r * TILE_COLS + c + Math.floor(Math.random() * 3)) % PALETTE.length]
      });
    }
  }
  const props = [];
  for (let i = 0; i < 10; i++) {
    const w = 55 + Math.random() * 55, h = 55 + Math.random() * 55;
    props.push({
      x: Math.random() * (WORLD_W - w),
      y: Math.random() * (WORLD_H - h - 160) + 80,
      w, h,
      color: PALETTE[Math.floor(Math.random() * PALETTE.length)]
    });
  }
  return { tiles, props };
}

function colorAt(map, x, y) {
  for (let i = map.props.length - 1; i >= 0; i--) {
    const p = map.props[i];
    if (x > p.x && x < p.x + p.w && y > p.y && y < p.y + p.h) return p.color;
  }
  for (const t of map.tiles) {
    if (x > t.x && x < t.x + t.w && y > t.y && y < t.y + t.h) return t.color;
  }
  return '#0d1417';
}

/** rooms[code] = {
 *   code, players: Map(id -> player), phase, timeLeft, map, loopHandle, hostId
 * }
 * player: { id, name, role, x, y, vx, vy, facing, color, alive, score, lastShot, spotCooldowns: Map }
 */
const rooms = new Map();

function publicPlayer(p) {
  return {
    id: p.id, name: p.name, x: p.x, y: p.y, color: p.color,
    alive: p.alive, isSeeker: p.role === 'seeker', score: p.score, facing: p.facing
  };
}

function broadcastLobby(room) {
  io.to(room.code).emit('lobby', {
    code: room.code,
    hostId: room.hostId,
    players: [...room.players.values()].map(p => ({ id: p.id, name: p.name }))
  });
}

function startRoom(room) {
  const ids = [...room.players.keys()];
  if (ids.length < 2) return;
  // shuffle
  for (let i = ids.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [ids[i], ids[j]] = [ids[j], ids[i]];
  }
  const seekerCount = Math.max(1, Math.round(ids.length * SEEKER_RATIO));
  room.map = buildMap();
  ids.forEach((id, idx) => {
    const p = room.players.get(id);
    p.role = idx < seekerCount ? 'seeker' : 'hider';
    p.x = WORLD_W / 2 + (Math.random() - 0.5) * 200;
    p.y = p.role === 'seeker' ? 60 + Math.random() * 40 : WORLD_H - 100 - Math.random() * 60;
    p.vx = 0; p.vy = 0; p.facing = 0;
    p.color = p.role === 'seeker' ? '#1c272b' : '#e9f5f3';
    p.alive = true;
    p.score = 0;
    p.lastShot = 0;
    p.spotCooldowns = new Map();
  });
  room.phase = 'hide';
  room.timeLeft = HIDE_PHASE_SEC;
  room.world = { w: WORLD_W, h: WORLD_H };

  io.to(room.code).emit('gameStart', {
    map: room.map,
    world: room.world,
    you: null, // filled per-socket below
    players: ids.map(id => ({ id, role: room.players.get(id).role, name: room.players.get(id).name }))
  });
  // tell each player their own role individually too (in case they missed the list)
  ids.forEach(id => {
    const sock = io.sockets.sockets.get(id);
    if (sock) sock.emit('yourRole', { role: room.players.get(id).role });
  });

  clearInterval(room.loopHandle);
  room.loopHandle = setInterval(() => tickRoom(room), TICK_MS);
}

function tickRoom(room) {
  const dt = TICK_MS / 1000;
  room.timeLeft -= dt;

  const hiders = [...room.players.values()].filter(p => p.role === 'hider');
  const seekers = [...room.players.values()].filter(p => p.role === 'seeker');
  const aliveHiders = hiders.filter(p => p.alive);

  for (const p of room.players.values()) {
    const canMove = room.phase === 'hide' ? p.role === 'hider' : p.alive;
    if (canMove) {
      p.x += p.vx * PLAYER_SPEED;
      p.y += p.vy * PLAYER_SPEED;
      p.x = Math.max(PLAYER_R, Math.min(WORLD_W - PLAYER_R, p.x));
      p.y = Math.max(PLAYER_R, Math.min(WORLD_H - PLAYER_R, p.y));
      if (p.vx !== 0 || p.vy !== 0) p.facing = Math.atan2(p.vy, p.vx);
    }
  }

  if (room.phase === 'seek') {
    const now = Date.now();
    for (const s of seekers) {
      for (const h of aliveHiders) {
        const dx = h.x - s.x, dy = h.y - s.y;
        const d = Math.hypot(dx, dy);
        if (d < SHOOT_RANGE) {
          const ang = Math.atan2(dy, dx);
          let diff = Math.abs(((ang - s.facing + Math.PI * 3) % (Math.PI * 2)) - Math.PI);
          if (diff < SHOOT_FOV / 2) {
            const key = s.id;
            const last = h.spotCooldowns.get(key) || 0;
            if (now - last > SPOT_BONUS_COOLDOWN_MS) {
              h.spotCooldowns.set(key, now);
              h.score += 3;
              io.to(room.code).emit('spotted', { hiderId: h.id });
            }
          }
        }
      }
    }
    for (const h of aliveHiders) h.score += dt * 0.6; // slow survival trickle

    if (room.timeLeft <= 0 || aliveHiders.length === 0) {
      endRound(room, aliveHiders.length > 0 ? 'hiders' : 'seekers');
      return;
    }
  } else if (room.phase === 'hide') {
    if (room.timeLeft <= 0) {
      room.phase = 'seek';
      room.timeLeft = SEEK_PHASE_SEC;
    }
  }

  io.to(room.code).emit('state', {
    phase: room.phase,
    timeLeft: Math.max(0, room.timeLeft),
    players: [...room.players.values()].map(publicPlayer)
  });
}

function endRound(room, winner) {
  clearInterval(room.loopHandle);
  room.phase = 'results';
  const scores = [...room.players.values()]
    .map(p => ({ name: p.name, role: p.role, score: Math.round(p.score), alive: p.alive }))
    .sort((a, b) => b.score - a.score);
  io.to(room.code).emit('roundEnd', { winner, scores });
}

io.on('connection', (socket) => {
  socket.on('createRoom', ({ name }) => {
    let code = makeRoomCode();
    while (rooms.has(code)) code = makeRoomCode();
    const room = { code, players: new Map(), phase: 'lobby', hostId: socket.id, loopHandle: null };
    rooms.set(code, room);
    room.players.set(socket.id, {
      id: socket.id, name: (name || 'Spieler').slice(0, 16), role: null,
      x: WORLD_W / 2, y: WORLD_H / 2, vx: 0, vy: 0, facing: 0,
      color: '#ffffff', alive: true, score: 0, lastShot: 0, spotCooldowns: new Map()
    });
    socket.join(code);
    socket.data.room = code;
    socket.emit('roomCreated', { code });
    broadcastLobby(room);
  });

  socket.on('joinRoom', ({ name, code }) => {
    const room = rooms.get((code || '').toUpperCase());
    if (!room) { socket.emit('joinError', { message: 'Raum nicht gefunden.' }); return; }
    if (room.phase !== 'lobby') { socket.emit('joinError', { message: 'Runde läuft bereits.' }); return; }
    if (room.players.size >= MAX_PLAYERS) { socket.emit('joinError', { message: 'Raum ist voll.' }); return; }
    room.players.set(socket.id, {
      id: socket.id, name: (name || 'Spieler').slice(0, 16), role: null,
      x: WORLD_W / 2, y: WORLD_H / 2, vx: 0, vy: 0, facing: 0,
      color: '#ffffff', alive: true, score: 0, lastShot: 0, spotCooldowns: new Map()
    });
    socket.join(room.code);
    socket.data.room = room.code;
    socket.emit('roomJoined', { code: room.code });
    broadcastLobby(room);
  });

  socket.on('startGame', () => {
    const room = rooms.get(socket.data.room);
    if (!room || room.hostId !== socket.id) return;
    startRoom(room);
  });

  socket.on('move', ({ vx, vy }) => {
    const room = rooms.get(socket.data.room);
    if (!room) return;
    const p = room.players.get(socket.id);
    if (!p) return;
    const mag = Math.hypot(vx, vy) || 1;
    const clampedMag = Math.min(mag, 1);
    p.vx = (vx / mag) * clampedMag;
    p.vy = (vy / mag) * clampedMag;
    if (vx === 0 && vy === 0) { p.vx = 0; p.vy = 0; }
  });

  socket.on('paint', () => {
    const room = rooms.get(socket.data.room);
    if (!room || room.phase === 'lobby' || room.phase === 'results') return;
    const p = room.players.get(socket.id);
    if (!p || p.role !== 'hider' || !p.alive) return;
    p.color = colorAt(room.map, p.x, p.y);
  });

  socket.on('shoot', () => {
    const room = rooms.get(socket.data.room);
    if (!room || room.phase !== 'seek') return;
    const s = room.players.get(socket.id);
    if (!s || s.role !== 'seeker') return;
    const now = Date.now();
    if (now - s.lastShot < SHOOT_COOLDOWN_MS) return;
    s.lastShot = now;

    let best = null, bestDist = Infinity;
    for (const h of room.players.values()) {
      if (h.role !== 'hider' || !h.alive) continue;
      const dx = h.x - s.x, dy = h.y - s.y;
      const d = Math.hypot(dx, dy);
      if (d > SHOOT_RANGE) continue;
      const ang = Math.atan2(dy, dx);
      let diff = Math.abs(((ang - s.facing + Math.PI * 3) % (Math.PI * 2)) - Math.PI);
      if (diff < SHOOT_FOV / 2 && d < bestDist) { best = h; bestDist = d; }
    }
    io.to(room.code).emit('shotFired', { seekerId: s.id, hit: !!best, hiderId: best ? best.id : null });
    if (best) {
      best.alive = false;
      s.score += 15;
    }
  });

  socket.on('disconnect', () => {
    const code = socket.data.room;
    const room = rooms.get(code);
    if (!room) return;
    room.players.delete(socket.id);
    if (room.players.size === 0) {
      clearInterval(room.loopHandle);
      rooms.delete(code);
      return;
    }
    if (room.hostId === socket.id) room.hostId = [...room.players.keys()][0];
    if (room.phase === 'lobby') broadcastLobby(room);
  });
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => console.log('Server läuft auf Port ' + PORT));
